
import java.util.regex.*;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

public class SimpleServlet extends HttpServlet {

    private void not_enough(PrintWriter out) {
        try {
            error(out, "<h1 align=\"center\">!NOT ENOUGH INFORMATION!</h1>");
        }
        finally {
            out.close();
        }
    }

    private void error(PrintWriter out, String s) {
        out.println("<!DOCTYPE html>");
        out.println("<html>");
        out.println("<head>");
        out.println("<title>ERROR</title>");
        out.println("</head>");
        out.println("<body>");
        out.println(s);
        out.println("<h3 align=\"center\">Please try again</h3>");
        out.println("</body>");
        out.println("</html>");
    }

    private void wrong_symbols(PrintWriter out) {
        try {
            error(out, "<h1 align=\"center\">!YOUR ARRAY CONTAINS FORBIDDEN SYMBOLS!</h1>");
        }
        finally {
            out.close();
        }
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        processRequest(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        processRequest(req, resp);
    }

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {


        int sum=0;
        int count=0;
        int max=0;
        int min=0;

        PrintWriter out = response.getWriter();
        try {
            String monday = request.getParameter("monday").replaceAll(" ", "");
            String tuesday = request.getParameter("tuesday").replaceAll(" ", "");
            String wednesday = request.getParameter("wednesday").replaceAll(" ", "");
            String thursday = request.getParameter("thursday").replaceAll(" ", "");
            String friday = request.getParameter("friday").replaceAll(" ", "");
            String saturday = request.getParameter("saturday").replaceAll(" ", "");
            String sunday = request.getParameter("sunday").replaceAll(" ", "");


            String[] week = {monday, tuesday, wednesday, thursday, friday, saturday, sunday};
            Pattern pattern = Pattern.compile("^-?[0-9]+$");

            max = Integer.parseInt(week[0]);
            min = Integer.parseInt(week[0]);

            for (int i = 0; i < week.length; i++) {
                Matcher matcher = pattern.matcher(week[i]);
                if (week[i].equals("")) {
                    not_enough(out);
                } else if (!matcher.find()) {
                    wrong_symbols(out);
                }

                sum += Integer.parseInt(week[i]);

                if (Integer.parseInt(week[i]) < max) {
                    min = Integer.parseInt(week[i]);
                }

                if (Integer.parseInt(week[i]) > min) {
                    max = Integer.parseInt(week[i]);
                }
            }

            int avrg = sum / week.length;
            for (int i = 0; i < week.length; i++) {
                if (avrg < Integer.parseInt(week[i])) {
                    count += 1;
                }
            }

            try {
                /* TODO output your page here. You may use following sample code. */
                out.println("<!DOCTYPE html>");
                out.println("<html>");
                out.println("<head>");
                out.println("<meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\" />\n" +
                        "\n");
                out.println("<title>Task</title>");
                out.println("<br>");
                out.println("<style>\n" +
                        "table {\n" +
                        "  width:70%;\n" +
                        "}\n" +
                        "table, th, td {\n" +
                        "  border: 1px solid black;\n" +
                        "  border-collapse: collapse;\n" +
                        "}\n" +
                        "th, td {\n" +
                        "  padding: 15px;\n" +
                        "  text-align: left;\n" +
                        "  width: 50%;\n"+
                        "}\n" +
                        "table#t01 th {\n" +
                        "  background-color: black;\n" +
                        "  color: white;\n" +
                        "}\n" +
                        "</style>");
                out.println("</head>");
                out.println("<body>");
                out.println("<table>");
                out.println("<tr>");
                out.println("<th>Average temperature</th>");
                out.println("<td>" + avrg + "<td/>");
                out.println("/<tr>");
                out.println("<th>Max temperature</th>");
                out.println("<td>" + max + "<td/>");
                out.println("/<tr>");
                out.println("<th>Min temperature</th>");
                out.println("<td>" + min + "<td/>");
                out.println("/<tr>");
                out.println("<th>Number of warmest days</th>");
                out.println("<td>" + count + "<td/>");
                out.println("/<tr>");
                out.println("</table>");
                out.println("</body>");
                out.println("</html>");
            } finally {
                out.close();
            }
        }
        catch (NumberFormatException error){
            wrong_symbols(out);
        }
    }
}

