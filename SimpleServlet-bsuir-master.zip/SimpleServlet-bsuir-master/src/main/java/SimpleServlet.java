import java.util.regex.*;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.lang.reflect.Array;
import java.util.Arrays;

public class SimpleServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        processRequest(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        processRequest(req, resp);
    }

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        String raw_array = request.getParameter("array");

        raw_array = raw_array.replaceAll(" ", "");

        Pattern pattern =  Pattern.compile("[a-zA-Z]");
        Matcher matcher = pattern.matcher(raw_array);

        if (matcher.find()) {
            try {
                out.println("<!DOCTYPE html>");
                out.println("<html>");
                out.println("<head>");
                out.println("<title>ERROR</title>");
                out.println("</head>");
                out.println("<body>");
                out.println("<h1 align=\"center\">!YOUR ARRAY CONTAINS LETTERS!</h1>");
                out.println("<h3 align=\"center\">Please try again</h3>");
                out.println("</body>");
                out.println("</html>");
            }
            finally {
                out.close();
            }
        } else {
//            if (raw_array.contains(" ")) {
//                raw_array = raw_array.replaceAll(" ", "");
//            }
            String[] split_array = raw_array.split(",");
            int size = split_array.length;
            int[] arr = new int[size];
            for (int i = 0; i < size; i++) {
                arr[i] = Integer.parseInt(split_array[i]);
            }

            for (int i = 0; i < arr.length - 1; i++) {
                for (int j = 0; j < arr.length - i - 1; j++) {
                    if (arr[j] > arr[j + 1]) {
                        int temp = arr[j];
                        arr[j] = arr[j + 1];
                        arr[j + 1] = temp;
                    }
                }
            }

            try {

                /* TODO output your page here. You may use following sample code. */
                out.println("<!DOCTYPE html>");
                out.println("<html>");
                out.println("<head>");
                out.println("<title>Task</title>");
                out.println("<style>\n" +
                        "table {\n" +
                        "  width:100%;\n" +
                        "}\n" +
                        "table, th, td {\n" +
                        "  border: 1px solid black;\n" +
                        "  border-collapse: collapse;\n" +
                        "}\n" +
                        "th, td {\n" +
                        "  padding: 15px;\n" +
                        "  text-align: left;\n" +
                        "}\n" +
                        "table#t01 tr:nth-child(even) {\n" +
                        "  background-color: #eee;\n" +
                        "}\n" +
                        "table#t01 tr:nth-child(odd) {\n" +
                        " background-color: #fff;\n" +
                        "}\n" +
                        "table#t01 th {\n" +
                        "  background-color: black;\n" +
                        "  color: white;\n" +
                        "}\n" +
                        "</style>");
                out.println("</head>");
                out.println("<body>");
                out.println("<table>");
                out.println("<tr>");
                out.println("<th>First Array");
                for (int i = 0; i < split_array.length; i++) {
                    out.println("<td>" + split_array[i] + "</td>");
                }
                out.println("</th>");
                out.println("</tr>");
                out.println("<tr>");
                out.println("<th>Sorted Array");
                for (int i = 0; i < arr.length; i++) {
                    out.println("<td>" + arr[i] + "</td>");
                }
                out.println("</tr>");
                out.println("</th>");
                out.println("</table>");
                out.println("</body>");
                out.println("</html>");
            } finally {
                out.close();
            }
        }
    }
}

